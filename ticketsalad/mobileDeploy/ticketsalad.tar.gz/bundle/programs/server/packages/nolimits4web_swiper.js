(function () {



/* Exports */
Package._define("nolimits4web:swiper");

})();
