(function () {



/* Exports */
Package._define("dab0mb:ionic-assets");

})();
