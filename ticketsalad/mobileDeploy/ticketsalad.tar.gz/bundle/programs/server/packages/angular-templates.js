(function () {



/* Exports */
Package._define("angular-templates");

})();
