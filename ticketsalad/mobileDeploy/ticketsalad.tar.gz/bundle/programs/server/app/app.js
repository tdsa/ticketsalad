var require = meteorInstall({"lib":{"collections.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// lib/collections.js                                                                      //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
module.export({
  Events: () => Events,
  Notifications: () => Notifications
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Events = new Mongo.Collection('events');
const Notifications = new Mongo.Collection('notifications');
/////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// lib/methods.js                                                                          //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Events, Notifications;
module.watch(require("../lib/collections"), {
  Events(v) {
    Events = v;
  },

  Notifications(v) {
    Notifications = v;
  }

}, 1);
let Email;
module.watch(require("meteor/email"), {
  Email(v) {
    Email = v;
  }

}, 2);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 3);
Meteor.methods({
  updatePicture(data) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'Must be logged in to update his picture.');
    }

    return Meteor.users.update(this.userId, {
      $set: {
        'profile.picture': data
      }
    });
  },

  updateEmail(newEmail) {
    Meteor.users.update(this.userId, {
      $set: {
        'email': newEmail
      }
    });
  },

  updateUsername(newUser) {
    Meteor.users.update(this.userId, {
      $set: {
        'username': newUser
      }
    });
  },

  verifyEmailAddress(id) {
    Accounts.sendVerificationEmail(Meteor.userId());
  },

  getEmail() {
    return Meteor.user().email;
  },

  sendEmail(from, subject, text) {
    var to = Meteor.user().email;
    this.unblock();
    Email.send({
      to,
      from,
      subject,
      text
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"bootstrap.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// server/bootstrap.js                                                                     //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
let Moment;
module.watch(require("moment"), {
  default(v) {
    Moment = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Events, Notifications;
module.watch(require("../lib/collections"), {
  Events(v) {
    Events = v;
  },

  Notifications(v) {
    Notifications = v;
  }

}, 2);
Meteor.startup(function () {
  process.env.MAIL_URL = 'smtp://tristan.jules:1009703Troy@smtp.gmail.com:587/';

  function generateCode() {
    var code = "";

    for (var index = 0; index < 6; index++) {
      var digit = Math.floor(Math.random() * 10);
      code += digit + "";
    } //Console.log(code);


    return code;
  }

  Events.remove({}); //clears the collection

  const events = [{
    name: 'Tomorrowland',
    city: 'Boom',
    country: 'Belgium',
    picture: 'img/TL.jpg',
    year: '2018',
    from: '21 July 2018',
    to: 'Jul 29, 2018',
    webpage: 'https://www.tomorrowland.com/en/festival/welcome',
    credits: '15',
    description: '',
    claims: 4,
    code: generateCode(),
    claimed: 0,
    winner: null,
    tickets: 2,
    about: "Tomorrowland is an electronic dance music festival held in Boom, Belgium. Tomorrowland was first held in 2005, and has since become one of the world's largest and most notable music festivals. It now stretches over 2 weekends and usually sells out in minutes.",
    subscribedUsers: []
  }, {
    name: 'Rocking The Daisies',
    city: 'New York',
    country: 'America',
    picture: 'img/RTD.jpg',
    year: '2018',
    from: '5 Oct 2018',
    to: 'Oct 7, 2018',
    webpage: 'https://rockingthedaisies.com/',
    credits: '5',
    description: '',
    claims: 1,
    code: generateCode(),
    claimed: 0,
    winner: null,
    tickets: 4,
    about: "Rocking the Daisies is Cape Town's biggest outdoor gathering, and it's become one of the highlights of the festival calendar. The event takes place on the stunning Cloof Wine Estate, just outside Darling, about an hour's drive from Cape Town.",
    subscribedUsers: []
  }, {
    name: 'Oppi Koppi',
    city: 'Johannesburg',
    country: 'South Africa',
    picture: 'img/oppi.png',
    year: '2018',
    from: '5 Aug 2018',
    to: 'Oct 7, 2018',
    webpage: 'https://rockingthedaisies.com/',
    credits: '5',
    description: '',
    claims: 3,
    code: generateCode(),
    claimed: 0,
    winner: null,
    tickets: 2,
    about: "OppiKoppi is a music festival held in the Limpopo Province of South Africa, near the mining town of Northam. The festival started off focusing mostly on rock music, but gradually added more genres and now plays host to a complete mixed bag of genres.",
    subscribedUsers: []
  }, {
    name: 'Holi Festival of Color',
    city: 'Mumbai',
    country: 'India',
    picture: 'img/holi.jpg',
    year: '2019',
    from: '4 March 2019',
    to: 'Oct 7, 2018',
    webpage: 'https://rockingthedaisies.com/',
    credits: '5',
    description: '',
    claims: 1,
    code: generateCode(),
    claimed: 0,
    winner: null,
    tickets: 2,
    about: "Holi is an ancient Hindu religious festival which has become popular with non-Hindus in many parts of South Asia, as well as people of other communities outside Asia. In addition to India and Nepal, the festival is celebrated by Indian subcontinent diaspora in countries such as Jamaica.",
    subscribedUsers: []
  }, {
    name: 'In The City',
    city: 'Moscow',
    country: 'Russia',
    picture: 'img/ITC.png',
    year: '2018',
    from: '7 Oct 2018',
    to: 'Oct 9, 2018',
    webpage: 'http://inthecityjhb.co.za/',
    credits: '5',
    description: '',
    claims: 3,
    code: generateCode(),
    claimed: 0,
    winner: null,
    tickets: 1,
    about: "In The City was started in 2012 by Seed Experiences, the same company responsible for the Cape Town festival Rocking The Daisies. As such, both of the festivals have shared headlining acts since In The City's inception in 2012 and the first year's edition hosted Bloc Party as its international headlining act.",
    subscribedUsers: []
  }];
  events.forEach(event => {
    const eventId = Events.insert(event); //Inserts into collections
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/lib/collections.js");
require("/lib/methods.js");
require("/server/bootstrap.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2Jvb3RzdHJhcC5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJFdmVudHMiLCJOb3RpZmljYXRpb25zIiwiTW9uZ28iLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiQ29sbGVjdGlvbiIsIk1ldGVvciIsIkVtYWlsIiwiQWNjb3VudHMiLCJtZXRob2RzIiwidXBkYXRlUGljdHVyZSIsImRhdGEiLCJ1c2VySWQiLCJFcnJvciIsInVzZXJzIiwidXBkYXRlIiwiJHNldCIsInVwZGF0ZUVtYWlsIiwibmV3RW1haWwiLCJ1cGRhdGVVc2VybmFtZSIsIm5ld1VzZXIiLCJ2ZXJpZnlFbWFpbEFkZHJlc3MiLCJpZCIsInNlbmRWZXJpZmljYXRpb25FbWFpbCIsImdldEVtYWlsIiwidXNlciIsImVtYWlsIiwic2VuZEVtYWlsIiwiZnJvbSIsInN1YmplY3QiLCJ0ZXh0IiwidG8iLCJ1bmJsb2NrIiwic2VuZCIsIk1vbWVudCIsImRlZmF1bHQiLCJzdGFydHVwIiwicHJvY2VzcyIsImVudiIsIk1BSUxfVVJMIiwiZ2VuZXJhdGVDb2RlIiwiY29kZSIsImluZGV4IiwiZGlnaXQiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJyZW1vdmUiLCJldmVudHMiLCJuYW1lIiwiY2l0eSIsImNvdW50cnkiLCJwaWN0dXJlIiwieWVhciIsIndlYnBhZ2UiLCJjcmVkaXRzIiwiZGVzY3JpcHRpb24iLCJjbGFpbXMiLCJjbGFpbWVkIiwid2lubmVyIiwidGlja2V0cyIsImFib3V0Iiwic3Vic2NyaWJlZFVzZXJzIiwiZm9yRWFjaCIsImV2ZW50IiwiZXZlbnRJZCIsImluc2VydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLFVBQU8sTUFBSUEsTUFBWjtBQUFtQkMsaUJBQWMsTUFBSUE7QUFBckMsQ0FBZDtBQUFtRSxJQUFJQyxLQUFKO0FBQVVKLE9BQU9LLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsUUFBTUcsQ0FBTixFQUFRO0FBQUNILFlBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFXdEUsTUFBTUwsU0FBUyxJQUFJRSxNQUFNSSxVQUFWLENBQXFCLFFBQXJCLENBQWY7QUFDQSxNQUFNTCxnQkFBZ0IsSUFBSUMsTUFBTUksVUFBVixDQUFxQixlQUFyQixDQUF0QixDOzs7Ozs7Ozs7OztBQ1pQLElBQUlDLE1BQUo7QUFBV1QsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRyxTQUFPRixDQUFQLEVBQVM7QUFBQ0UsYUFBT0YsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJTCxNQUFKLEVBQVdDLGFBQVg7QUFBeUJILE9BQU9LLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUNKLFNBQU9LLENBQVAsRUFBUztBQUFDTCxhQUFPSyxDQUFQO0FBQVMsR0FBcEI7O0FBQXFCSixnQkFBY0ksQ0FBZCxFQUFnQjtBQUFDSixvQkFBY0ksQ0FBZDtBQUFnQjs7QUFBdEQsQ0FBM0MsRUFBbUcsQ0FBbkc7QUFBc0csSUFBSUcsS0FBSjtBQUFVVixPQUFPSyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFFBQU1ILENBQU4sRUFBUTtBQUFDRyxZQUFNSCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlJLFFBQUo7QUFBYVgsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRUFBNkM7QUFBQ0ssV0FBU0osQ0FBVCxFQUFXO0FBQUNJLGVBQVNKLENBQVQ7QUFBVzs7QUFBeEIsQ0FBN0MsRUFBdUUsQ0FBdkU7QUFLNVJFLE9BQU9HLE9BQVAsQ0FBZTtBQUNYQyxnQkFBY0MsSUFBZCxFQUNBO0FBQ0ksUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDaEIsWUFBTSxJQUFJTixPQUFPTyxLQUFYLENBQWlCLGVBQWpCLEVBQ0osMENBREksQ0FBTjtBQUVEOztBQUVELFdBQU9QLE9BQU9RLEtBQVAsQ0FBYUMsTUFBYixDQUFvQixLQUFLSCxNQUF6QixFQUFpQztBQUFFSSxZQUFNO0FBQUUsMkJBQW1CTDtBQUFyQjtBQUFSLEtBQWpDLENBQVA7QUFDSCxHQVRVOztBQVdYTSxjQUFZQyxRQUFaLEVBQ0E7QUFDSVosV0FBT1EsS0FBUCxDQUFhQyxNQUFiLENBQW9CLEtBQUtILE1BQXpCLEVBQWlDO0FBQUVJLFlBQU07QUFBRSxpQkFBU0U7QUFBWDtBQUFSLEtBQWpDO0FBQ0gsR0FkVTs7QUFnQlhDLGlCQUFlQyxPQUFmLEVBQ0E7QUFDSWQsV0FBT1EsS0FBUCxDQUFhQyxNQUFiLENBQW9CLEtBQUtILE1BQXpCLEVBQWlDO0FBQUVJLFlBQU07QUFBRSxvQkFBWUk7QUFBZDtBQUFSLEtBQWpDO0FBQ0gsR0FuQlU7O0FBcUJYQyxxQkFBbUJDLEVBQW5CLEVBQ0E7QUFDSWQsYUFBU2UscUJBQVQsQ0FBK0JqQixPQUFPTSxNQUFQLEVBQS9CO0FBQ0gsR0F4QlU7O0FBMEJYWSxhQUNBO0FBQ0ksV0FBT2xCLE9BQU9tQixJQUFQLEdBQWNDLEtBQXJCO0FBQ0gsR0E3QlU7O0FBK0JYQyxZQUFVQyxJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsSUFBekIsRUFBK0I7QUFDM0IsUUFBSUMsS0FBS3pCLE9BQU9tQixJQUFQLEdBQWNDLEtBQXZCO0FBQ0EsU0FBS00sT0FBTDtBQUNBekIsVUFBTTBCLElBQU4sQ0FBVztBQUFFRixRQUFGO0FBQU1ILFVBQU47QUFBWUMsYUFBWjtBQUFxQkM7QUFBckIsS0FBWDtBQUNIOztBQW5DVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSUksTUFBSjtBQUFXckMsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDZ0MsVUFBUS9CLENBQVIsRUFBVTtBQUFDOEIsYUFBTzlCLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUUsTUFBSjtBQUFXVCxPQUFPSyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNHLFNBQU9GLENBQVAsRUFBUztBQUFDRSxhQUFPRixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlMLE1BQUosRUFBV0MsYUFBWDtBQUF5QkgsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ0osU0FBT0ssQ0FBUCxFQUFTO0FBQUNMLGFBQU9LLENBQVA7QUFBUyxHQUFwQjs7QUFBcUJKLGdCQUFjSSxDQUFkLEVBQWdCO0FBQUNKLG9CQUFjSSxDQUFkO0FBQWdCOztBQUF0RCxDQUEzQyxFQUFtRyxDQUFuRztBQWV2S0UsT0FBTzhCLE9BQVAsQ0FBZSxZQUNmO0FBQ0lDLFVBQVFDLEdBQVIsQ0FBWUMsUUFBWixHQUF1QixzREFBdkI7O0FBRUEsV0FBU0MsWUFBVCxHQUNBO0FBQ0ksUUFBSUMsT0FBTyxFQUFYOztBQUNBLFNBQUssSUFBSUMsUUFBUSxDQUFqQixFQUFvQkEsUUFBUSxDQUE1QixFQUErQkEsT0FBL0IsRUFDQTtBQUNJLFVBQUlDLFFBQVFDLEtBQUtDLEtBQUwsQ0FBWUQsS0FBS0UsTUFBTCxLQUFnQixFQUE1QixDQUFaO0FBQ0FMLGNBQVFFLFFBQVEsRUFBaEI7QUFDSCxLQU5MLENBT0k7OztBQUNBLFdBQU9GLElBQVA7QUFDSDs7QUFFRDFDLFNBQU9nRCxNQUFQLENBQWMsRUFBZCxFQWZKLENBZXVCOztBQUVuQixRQUFNQyxTQUFTLENBQ2Y7QUFDSUMsVUFBTSxjQURWO0FBRUlDLFVBQU0sTUFGVjtBQUdJQyxhQUFTLFNBSGI7QUFJSUMsYUFBUyxZQUpiO0FBS0lDLFVBQU0sTUFMVjtBQU1JekIsVUFBTSxjQU5WO0FBT0lHLFFBQUksY0FQUjtBQVFJdUIsYUFBUyxrREFSYjtBQVNJQyxhQUFTLElBVGI7QUFVSUMsaUJBQWEsRUFWakI7QUFXSUMsWUFBUSxDQVhaO0FBWUloQixVQUFNRCxjQVpWO0FBYUlrQixhQUFTLENBYmI7QUFjSUMsWUFBUSxJQWRaO0FBZUlDLGFBQVMsQ0FmYjtBQWdCSUMsV0FBTyxxUUFoQlg7QUFpQklDLHFCQUFpQjtBQWpCckIsR0FEZSxFQXFCZjtBQUNJYixVQUFNLHFCQURWO0FBRUlDLFVBQU0sVUFGVjtBQUdJQyxhQUFTLFNBSGI7QUFJSUMsYUFBUyxhQUpiO0FBS0lDLFVBQU0sTUFMVjtBQU1JekIsVUFBTSxZQU5WO0FBT0lHLFFBQUksYUFQUjtBQVFJdUIsYUFBUyxnQ0FSYjtBQVNJQyxhQUFTLEdBVGI7QUFVSUMsaUJBQWEsRUFWakI7QUFXSUMsWUFBUSxDQVhaO0FBWUloQixVQUFNRCxjQVpWO0FBYUlrQixhQUFTLENBYmI7QUFjSUMsWUFBUSxJQWRaO0FBZUlDLGFBQVMsQ0FmYjtBQWdCSUMsV0FBTyxvUEFoQlg7QUFpQklDLHFCQUFpQjtBQWpCckIsR0FyQmUsRUF3Q2Y7QUFDSWIsVUFBTSxZQURWO0FBRUlDLFVBQU0sY0FGVjtBQUdJQyxhQUFTLGNBSGI7QUFJSUMsYUFBUyxjQUpiO0FBS0lDLFVBQU0sTUFMVjtBQU1JekIsVUFBTSxZQU5WO0FBT0lHLFFBQUksYUFQUjtBQVFJdUIsYUFBUyxnQ0FSYjtBQVNJQyxhQUFTLEdBVGI7QUFVSUMsaUJBQWEsRUFWakI7QUFXSUMsWUFBUSxDQVhaO0FBWUloQixVQUFNRCxjQVpWO0FBYUlrQixhQUFTLENBYmI7QUFjSUMsWUFBUSxJQWRaO0FBZUlDLGFBQVMsQ0FmYjtBQWdCSUMsV0FBTyw0UEFoQlg7QUFpQklDLHFCQUFpQjtBQWpCckIsR0F4Q2UsRUEyRGY7QUFDSWIsVUFBTSx3QkFEVjtBQUVJQyxVQUFNLFFBRlY7QUFHSUMsYUFBUyxPQUhiO0FBSUlDLGFBQVMsY0FKYjtBQUtJQyxVQUFNLE1BTFY7QUFNSXpCLFVBQU0sY0FOVjtBQU9JRyxRQUFJLGFBUFI7QUFRSXVCLGFBQVMsZ0NBUmI7QUFTSUMsYUFBUyxHQVRiO0FBVUlDLGlCQUFhLEVBVmpCO0FBV0lDLFlBQVEsQ0FYWjtBQVlJaEIsVUFBTUQsY0FaVjtBQWFJa0IsYUFBUyxDQWJiO0FBY0lDLFlBQVEsSUFkWjtBQWVJQyxhQUFTLENBZmI7QUFnQklDLFdBQU8saVNBaEJYO0FBaUJJQyxxQkFBaUI7QUFqQnJCLEdBM0RlLEVBOEVmO0FBQ0liLFVBQU0sYUFEVjtBQUVJQyxVQUFNLFFBRlY7QUFHSUMsYUFBUyxRQUhiO0FBSUlDLGFBQVMsYUFKYjtBQUtJQyxVQUFNLE1BTFY7QUFNSXpCLFVBQU0sWUFOVjtBQU9JRyxRQUFJLGFBUFI7QUFRSXVCLGFBQVMsNEJBUmI7QUFTSUMsYUFBUyxHQVRiO0FBVUlDLGlCQUFhLEVBVmpCO0FBV0lDLFlBQVEsQ0FYWjtBQVlJaEIsVUFBTUQsY0FaVjtBQWFJa0IsYUFBUyxDQWJiO0FBY0lDLFlBQVEsSUFkWjtBQWVJQyxhQUFTLENBZmI7QUFnQklDLFdBQU8sd1RBaEJYO0FBaUJJQyxxQkFBaUI7QUFqQnJCLEdBOUVlLENBQWY7QUFrR0FkLFNBQU9lLE9BQVAsQ0FBZ0JDLEtBQUQsSUFBVztBQUN0QixVQUFNQyxVQUFVbEUsT0FBT21FLE1BQVAsQ0FBY0YsS0FBZCxDQUFoQixDQURzQixDQUNnQjtBQUN6QyxHQUZEO0FBR0gsQ0F2SEQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiogRmlsZSBOYW1lOiBjb2xsZWN0aW9ucy5qc1xuKiBWZXJzaW9uIDEuMFxuKlxuKiBUcmlidXMgRGlnaXRhXG4qIFRpY2tldCBTYWxhZFxuKlxuKiBGdW5jdGlvbmFsIGRlc2NyaXB0aW9uOiBjb2xsZWN0aW9ucyBoYW5kbGVzIGFsbCBqYXZhc2NyaXB0IGFzc29jaWF0ZWQgd2l0aCBpbXBvcnRpbmcgbW9uZ28gbGlicmFyaWVzIGFuZCBjb2xsZWN0aW9uc1xuKi9cbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbiBcbmV4cG9ydCBjb25zdCBFdmVudHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZXZlbnRzJyk7XG5leHBvcnQgY29uc3QgTm90aWZpY2F0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdub3RpZmljYXRpb25zJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEV2ZW50cywgTm90aWZpY2F0aW9ucyB9IGZyb20gJy4uL2xpYi9jb2xsZWN0aW9ucyc7XG5pbXBvcnQgeyBFbWFpbCB9IGZyb20gJ21ldGVvci9lbWFpbCdcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnXG4gXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgdXBkYXRlUGljdHVyZShkYXRhKSBcbiAgICB7XG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJyxcbiAgICAgICAgICAgICdNdXN0IGJlIGxvZ2dlZCBpbiB0byB1cGRhdGUgaGlzIHBpY3R1cmUuJyk7XG4gICAgICAgIH1cbiAgICAgXG4gICAgICAgIHJldHVybiBNZXRlb3IudXNlcnMudXBkYXRlKHRoaXMudXNlcklkLCB7ICRzZXQ6IHsgJ3Byb2ZpbGUucGljdHVyZSc6IGRhdGEgfSB9KTtcbiAgICB9LFxuXG4gICAgdXBkYXRlRW1haWwobmV3RW1haWwpXG4gICAge1xuICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHRoaXMudXNlcklkLCB7ICRzZXQ6IHsgJ2VtYWlsJzogbmV3RW1haWwgfSB9KTtcbiAgICB9LFxuXG4gICAgdXBkYXRlVXNlcm5hbWUobmV3VXNlcilcbiAgICB7XG4gICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUodGhpcy51c2VySWQsIHsgJHNldDogeyAndXNlcm5hbWUnOiBuZXdVc2VyIH0gfSk7XG4gICAgfSxcblxuICAgIHZlcmlmeUVtYWlsQWRkcmVzcyhpZClcbiAgICB7XG4gICAgICAgIEFjY291bnRzLnNlbmRWZXJpZmljYXRpb25FbWFpbChNZXRlb3IudXNlcklkKCkpO1xuICAgIH0sXG5cbiAgICBnZXRFbWFpbCgpXG4gICAge1xuICAgICAgICByZXR1cm4gTWV0ZW9yLnVzZXIoKS5lbWFpbDtcbiAgICB9LFxuXG4gICAgc2VuZEVtYWlsKGZyb20sIHN1YmplY3QsIHRleHQpIHtcbiAgICAgICAgdmFyIHRvID0gTWV0ZW9yLnVzZXIoKS5lbWFpbFxuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgRW1haWwuc2VuZCh7IHRvLCBmcm9tLCBzdWJqZWN0LCB0ZXh0IH0pO1xuICAgIH0sXG5cbiAgICBcbn0pO1xuIiwiLypcbiogRmlsZSBOYW1lOiBib290c3RyYXAuanNcbiogVmVyc2lvbiAxLjBcbipcbiogVHJpYnVzIERpZ2l0YVxuKiBUaWNrZXQgU2FsYWRcbipcbiogRnVuY3Rpb25hbCBkZXNjcmlwdGlvbjogYm9vdHN0cmFwIGhhbmRsZXMgYWxsIGphdmFzY3JpcHQgYXNzb2NpYXRlZCB3aXRoIGNyZWF0aW5nIGEgbW9uZ28gY29sbGVjdGlvblxuKi9cblxuLy9saWJzXG5pbXBvcnQgTW9tZW50IGZyb20gJ21vbWVudCc7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEV2ZW50cywgTm90aWZpY2F0aW9ucyB9IGZyb20gJy4uL2xpYi9jb2xsZWN0aW9ucyc7XG4gXG5NZXRlb3Iuc3RhcnR1cChmdW5jdGlvbigpIFxue1xuICAgIHByb2Nlc3MuZW52Lk1BSUxfVVJMID0gJ3NtdHA6Ly90cmlzdGFuLmp1bGVzOjEwMDk3MDNUcm95QHNtdHAuZ21haWwuY29tOjU4Ny8nXG4gICAgXG4gICAgZnVuY3Rpb24gZ2VuZXJhdGVDb2RlKClcbiAgICB7XG4gICAgICAgIHZhciBjb2RlID0gXCJcIjtcbiAgICAgICAgZm9yICh2YXIgaW5kZXggPSAwOyBpbmRleCA8IDY7IGluZGV4KyspIFxuICAgICAgICB7XG4gICAgICAgICAgICB2YXIgZGlnaXQgPSBNYXRoLmZsb29yKChNYXRoLnJhbmRvbSgpICogMTApKTtcbiAgICAgICAgICAgIGNvZGUgKz0gZGlnaXQgKyBcIlwiO1xuICAgICAgICB9XG4gICAgICAgIC8vQ29uc29sZS5sb2coY29kZSk7XG4gICAgICAgIHJldHVybiBjb2RlO1xuICAgIH1cblxuICAgIEV2ZW50cy5yZW1vdmUoe30pOyAvL2NsZWFycyB0aGUgY29sbGVjdGlvblxuXG4gICAgY29uc3QgZXZlbnRzID0gW1xuICAgIHtcbiAgICAgICAgbmFtZTogJ1RvbW9ycm93bGFuZCcsXG4gICAgICAgIGNpdHk6ICdCb29tJyxcbiAgICAgICAgY291bnRyeTogJ0JlbGdpdW0nLFxuICAgICAgICBwaWN0dXJlOiAnaW1nL1RMLmpwZycsXG4gICAgICAgIHllYXI6ICcyMDE4JyxcbiAgICAgICAgZnJvbTogJzIxIEp1bHkgMjAxOCcsXG4gICAgICAgIHRvOiAnSnVsIDI5LCAyMDE4JyxcbiAgICAgICAgd2VicGFnZTogJ2h0dHBzOi8vd3d3LnRvbW9ycm93bGFuZC5jb20vZW4vZmVzdGl2YWwvd2VsY29tZScsXG4gICAgICAgIGNyZWRpdHM6ICcxNScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgICAgY2xhaW1zOiA0LFxuICAgICAgICBjb2RlOiBnZW5lcmF0ZUNvZGUoKSxcbiAgICAgICAgY2xhaW1lZDogMCxcbiAgICAgICAgd2lubmVyOiBudWxsLFxuICAgICAgICB0aWNrZXRzOiAyLFxuICAgICAgICBhYm91dDogXCJUb21vcnJvd2xhbmQgaXMgYW4gZWxlY3Ryb25pYyBkYW5jZSBtdXNpYyBmZXN0aXZhbCBoZWxkIGluIEJvb20sIEJlbGdpdW0uIFRvbW9ycm93bGFuZCB3YXMgZmlyc3QgaGVsZCBpbiAyMDA1LCBhbmQgaGFzIHNpbmNlIGJlY29tZSBvbmUgb2YgdGhlIHdvcmxkJ3MgbGFyZ2VzdCBhbmQgbW9zdCBub3RhYmxlIG11c2ljIGZlc3RpdmFscy4gSXQgbm93IHN0cmV0Y2hlcyBvdmVyIDIgd2Vla2VuZHMgYW5kIHVzdWFsbHkgc2VsbHMgb3V0IGluIG1pbnV0ZXMuXCIsXG4gICAgICAgIHN1YnNjcmliZWRVc2VyczogW10sXG4gICAgICAgIFxuICAgIH0sXG4gICAge1xuICAgICAgICBuYW1lOiAnUm9ja2luZyBUaGUgRGFpc2llcycsXG4gICAgICAgIGNpdHk6ICdOZXcgWW9yaycsXG4gICAgICAgIGNvdW50cnk6ICdBbWVyaWNhJyxcbiAgICAgICAgcGljdHVyZTogJ2ltZy9SVEQuanBnJyxcbiAgICAgICAgeWVhcjogJzIwMTgnLFxuICAgICAgICBmcm9tOiAnNSBPY3QgMjAxOCcsXG4gICAgICAgIHRvOiAnT2N0IDcsIDIwMTgnLFxuICAgICAgICB3ZWJwYWdlOiAnaHR0cHM6Ly9yb2NraW5ndGhlZGFpc2llcy5jb20vJyxcbiAgICAgICAgY3JlZGl0czogJzUnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICAgIGNsYWltczogMSxcbiAgICAgICAgY29kZTogZ2VuZXJhdGVDb2RlKCksXG4gICAgICAgIGNsYWltZWQ6IDAsXG4gICAgICAgIHdpbm5lcjogbnVsbCxcbiAgICAgICAgdGlja2V0czogNCxcbiAgICAgICAgYWJvdXQ6IFwiUm9ja2luZyB0aGUgRGFpc2llcyBpcyBDYXBlIFRvd24ncyBiaWdnZXN0IG91dGRvb3IgZ2F0aGVyaW5nLCBhbmQgaXQncyBiZWNvbWUgb25lIG9mIHRoZSBoaWdobGlnaHRzIG9mIHRoZSBmZXN0aXZhbCBjYWxlbmRhci4gVGhlIGV2ZW50IHRha2VzIHBsYWNlIG9uIHRoZSBzdHVubmluZyBDbG9vZiBXaW5lIEVzdGF0ZSwganVzdCBvdXRzaWRlIERhcmxpbmcsIGFib3V0IGFuIGhvdXIncyBkcml2ZSBmcm9tIENhcGUgVG93bi5cIixcbiAgICAgICAgc3Vic2NyaWJlZFVzZXJzOiBbXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogJ09wcGkgS29wcGknLFxuICAgICAgICBjaXR5OiAnSm9oYW5uZXNidXJnJyxcbiAgICAgICAgY291bnRyeTogJ1NvdXRoIEFmcmljYScsXG4gICAgICAgIHBpY3R1cmU6ICdpbWcvb3BwaS5wbmcnLFxuICAgICAgICB5ZWFyOiAnMjAxOCcsXG4gICAgICAgIGZyb206ICc1IEF1ZyAyMDE4JyxcbiAgICAgICAgdG86ICdPY3QgNywgMjAxOCcsXG4gICAgICAgIHdlYnBhZ2U6ICdodHRwczovL3JvY2tpbmd0aGVkYWlzaWVzLmNvbS8nLFxuICAgICAgICBjcmVkaXRzOiAnNScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgICAgY2xhaW1zOiAzLFxuICAgICAgICBjb2RlOiBnZW5lcmF0ZUNvZGUoKSxcbiAgICAgICAgY2xhaW1lZDogMCxcbiAgICAgICAgd2lubmVyOiBudWxsLFxuICAgICAgICB0aWNrZXRzOiAyLFxuICAgICAgICBhYm91dDogXCJPcHBpS29wcGkgaXMgYSBtdXNpYyBmZXN0aXZhbCBoZWxkIGluIHRoZSBMaW1wb3BvIFByb3ZpbmNlIG9mIFNvdXRoIEFmcmljYSwgbmVhciB0aGUgbWluaW5nIHRvd24gb2YgTm9ydGhhbS4gVGhlIGZlc3RpdmFsIHN0YXJ0ZWQgb2ZmIGZvY3VzaW5nIG1vc3RseSBvbiByb2NrIG11c2ljLCBidXQgZ3JhZHVhbGx5IGFkZGVkIG1vcmUgZ2VucmVzIGFuZCBub3cgcGxheXMgaG9zdCB0byBhIGNvbXBsZXRlIG1peGVkIGJhZyBvZiBnZW5yZXMuXCIsXG4gICAgICAgIHN1YnNjcmliZWRVc2VyczogW10sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICdIb2xpIEZlc3RpdmFsIG9mIENvbG9yJyxcbiAgICAgICAgY2l0eTogJ011bWJhaScsXG4gICAgICAgIGNvdW50cnk6ICdJbmRpYScsXG4gICAgICAgIHBpY3R1cmU6ICdpbWcvaG9saS5qcGcnLFxuICAgICAgICB5ZWFyOiAnMjAxOScsXG4gICAgICAgIGZyb206ICc0IE1hcmNoIDIwMTknLFxuICAgICAgICB0bzogJ09jdCA3LCAyMDE4JyxcbiAgICAgICAgd2VicGFnZTogJ2h0dHBzOi8vcm9ja2luZ3RoZWRhaXNpZXMuY29tLycsXG4gICAgICAgIGNyZWRpdHM6ICc1JyxcbiAgICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgICBjbGFpbXM6IDEsXG4gICAgICAgIGNvZGU6IGdlbmVyYXRlQ29kZSgpLFxuICAgICAgICBjbGFpbWVkOiAwLFxuICAgICAgICB3aW5uZXI6IG51bGwsXG4gICAgICAgIHRpY2tldHM6IDIsXG4gICAgICAgIGFib3V0OiBcIkhvbGkgaXMgYW4gYW5jaWVudCBIaW5kdSByZWxpZ2lvdXMgZmVzdGl2YWwgd2hpY2ggaGFzIGJlY29tZSBwb3B1bGFyIHdpdGggbm9uLUhpbmR1cyBpbiBtYW55IHBhcnRzIG9mIFNvdXRoIEFzaWEsIGFzIHdlbGwgYXMgcGVvcGxlIG9mIG90aGVyIGNvbW11bml0aWVzIG91dHNpZGUgQXNpYS4gSW4gYWRkaXRpb24gdG8gSW5kaWEgYW5kIE5lcGFsLCB0aGUgZmVzdGl2YWwgaXMgY2VsZWJyYXRlZCBieSBJbmRpYW4gc3ViY29udGluZW50IGRpYXNwb3JhIGluIGNvdW50cmllcyBzdWNoIGFzIEphbWFpY2EuXCIsXG4gICAgICAgIHN1YnNjcmliZWRVc2VyczogW10sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICdJbiBUaGUgQ2l0eScsXG4gICAgICAgIGNpdHk6ICdNb3Njb3cnLFxuICAgICAgICBjb3VudHJ5OiAnUnVzc2lhJyxcbiAgICAgICAgcGljdHVyZTogJ2ltZy9JVEMucG5nJyxcbiAgICAgICAgeWVhcjogJzIwMTgnLFxuICAgICAgICBmcm9tOiAnNyBPY3QgMjAxOCcsXG4gICAgICAgIHRvOiAnT2N0IDksIDIwMTgnLFxuICAgICAgICB3ZWJwYWdlOiAnaHR0cDovL2ludGhlY2l0eWpoYi5jby56YS8nLFxuICAgICAgICBjcmVkaXRzOiAnNScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgICAgY2xhaW1zOiAzLFxuICAgICAgICBjb2RlOiBnZW5lcmF0ZUNvZGUoKSxcbiAgICAgICAgY2xhaW1lZDogMCxcbiAgICAgICAgd2lubmVyOiBudWxsLFxuICAgICAgICB0aWNrZXRzOiAxLFxuICAgICAgICBhYm91dDogXCJJbiBUaGUgQ2l0eSB3YXMgc3RhcnRlZCBpbiAyMDEyIGJ5wqBTZWVkIEV4cGVyaWVuY2VzLCB0aGUgc2FtZSBjb21wYW55IHJlc3BvbnNpYmxlIGZvciB0aGXCoENhcGUgVG93bsKgZmVzdGl2YWzCoFJvY2tpbmcgVGhlIERhaXNpZXMuIEFzIHN1Y2gsIGJvdGggb2YgdGhlIGZlc3RpdmFscyBoYXZlIHNoYXJlZCBoZWFkbGluaW5nIGFjdHMgc2luY2UgSW4gVGhlIENpdHkncyBpbmNlcHRpb24gaW4gMjAxMiBhbmQgdGhlIGZpcnN0IHllYXIncyBlZGl0aW9uIGhvc3RlZMKgQmxvYyBQYXJ0ecKgYXMgaXRzIGludGVybmF0aW9uYWwgaGVhZGxpbmluZyBhY3QuXCIsXG4gICAgICAgIHN1YnNjcmliZWRVc2VyczogW10sXG4gICAgfV07XG5cbiAgICBldmVudHMuZm9yRWFjaCgoZXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgZXZlbnRJZCA9IEV2ZW50cy5pbnNlcnQoZXZlbnQpOyAvL0luc2VydHMgaW50byBjb2xsZWN0aW9uc1xuICAgIH0pO1xufSk7XG4iXX0=
